import React from 'react'

const CartItemsList = () => {
    return (
        <div>CartItemsList</div>
    )
}

export default CartItemsList