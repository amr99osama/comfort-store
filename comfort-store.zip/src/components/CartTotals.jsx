import React from 'react'

const CartTotals = () => {
    return (
        <h1 className='text-3xl'>CartTotals</h1>
    )
}

export default CartTotals