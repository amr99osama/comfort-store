import React from 'react'
import { useSelector } from 'react-redux'
import { cartItemsList, SectionTitle, CartTotals } from '../components'
import { Link } from 'react-router-dom'
const Cart = () => {
  return (
    <h1 className='text-3xl font-bold underline'>Cart</h1>
  )
}

export default Cart